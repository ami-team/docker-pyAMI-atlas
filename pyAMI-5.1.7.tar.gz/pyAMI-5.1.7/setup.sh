#!/bin/bash

if [[ ! -z ${PYAMI_HOME} ]]
then
  PYAMI_BUNDLE_DIR=${PYAMI_HOME}
else
  THIS_SCRIPT=${BASH_SOURCE[0]:-$0}

  while [[ "$(readlink ${THIS_SCRIPT})" != "" ]]
  do
    THIS_SCRIPT=$(readlink ${THIS_SCRIPT})
  done

  PYAMI_BUNDLE_DIR=$(cd "$(dirname ${THIS_SCRIPT})" && pwd)
fi

export PATH=${PYAMI_BUNDLE_DIR}/bin${PATH:+:$PATH}
export PYTHONPATH=${PYAMI_BUNDLE_DIR}/lib${PYTHONPATH:+:$PYTHONPATH}
export PYAMI_VERSION=5.1.7
